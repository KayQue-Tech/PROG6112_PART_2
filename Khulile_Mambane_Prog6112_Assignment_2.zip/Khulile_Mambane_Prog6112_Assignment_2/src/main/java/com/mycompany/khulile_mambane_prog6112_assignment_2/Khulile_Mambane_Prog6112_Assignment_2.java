package com.mycompany.khulile_mambane_prog6112_assignment_2;

import javax.swing.*;
import java.awt.Dimension;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class Khulile_Mambane_Prog6112_Assignment_2 {

    public static void main(String[] args) {
        Shell.start();
    }

    // Shared contract every rescue type must fulfil.
    interface RescueProtocol {
        String CREATED  = "New Rescue";
        String ENGAGED  = "Rescue in Progress";
        String WATCHING = "Under Observation";
        String RESOLVED = "Rescue Completed";

        void commence();
        void finalise();
        String card();
    }

    // Abstract base carrying common fields and defining type-specific behaviour.
    static abstract class RescueCase implements RescueProtocol {

        private String caseCode, animalName, species, site, ranger, state;
        private int dayCount;
        private double dayRate;

        RescueCase(String caseCode, String animalName, String species, String site,
                   String ranger, int dayCount, double dayRate, String state) {
            this.caseCode = caseCode;
            this.animalName = animalName;
            this.species = species;
            this.site = site;
            this.ranger = ranger;
            this.dayCount = dayCount;
            this.dayRate = dayRate;
            this.state = state;
        }

        String caseCode()   { return caseCode; }
        String animalName() { return animalName; }
        String species()    { return species; }
        String site()       { return site; }
        String ranger()     { return ranger; }
        String state()      { return state; }
        int dayCount()      { return dayCount; }
        double dayRate()    { return dayRate; }
        void state(String s) { state = s; }

        // Base = days worked multiplied by the daily rate.
        double fixedPortion() { return dayCount * dayRate; }

        // Rands with a space as the thousands separator and two decimals.
        static String rands(double v) {
            DecimalFormat f = new DecimalFormat("#,##0.00");
            return "R" + f.format(v).replace(",", " ");
        }

        abstract double grandTotal();
        abstract String tier();
        abstract String family();
        abstract String finerPoints();
    }

    // Injured rescue: base + medical + R5 000 if operation needed.
    // Tier: Critical if operation AND medical >= 12000; High if either; Medium if medical >= 4000; else Low.
    static class Wounded extends RescueCase {

        private String injuryNote;
        private double clinicFee;
        private boolean operation;

        Wounded(String caseCode, String animalName, String species, String site, String ranger,
                int dayCount, double dayRate, String state,
                String injuryNote, double clinicFee, boolean operation) {
            super(caseCode, animalName, species, site, ranger, dayCount, dayRate, state);
            this.injuryNote = injuryNote;
            this.clinicFee = clinicFee;
            this.operation = operation;
        }

        String injuryNote()   { return injuryNote; }
        double clinicFee()    { return clinicFee; }
        boolean operation()   { return operation; }

        @Override double grandTotal() {
            return fixedPortion() + clinicFee + (operation ? 5000.0 : 0.0);
        }

        @Override String tier() {
            if (operation && clinicFee >= 12000) return "Critical";
            if (operation || clinicFee >= 12000) return "High";
            if (clinicFee >= 4000)               return "Medium";
            return "Low";
        }

        @Override String family() { return "Injured Animal Rescue"; }

        @Override String finerPoints() {
            return "Injury Note           : " + injuryNote + "\n" +
                   "Clinic Fee            : " + rands(clinicFee) + "\n" +
                   "Operation             : " + (operation ? "Yes" : "No");
        }

        @Override public void commence() { state(ENGAGED); }
        @Override public void finalise() { state(RESOLVED); }

        @Override public String card() {
            return "Case ID           : " + caseCode() + "\n" +
                   "Type              : " + family() + "\n" +
                   "Species           : " + species() + "\n" +
                   "Ranger            : " + ranger() + "\n" +
                   "Priority          : " + tier() + "\n" +
                   "Status            : " + state() + "\n" +
                   "Total Cost        : " + rands(grandTotal());
        }
    }

    // Orphaned rescue: base + feeding + R2 500 if foster care needed.
    // Tier: Critical if age <= 2 AND foster; High if either; Medium if age <= 9; else Low.
    static class Nestling extends RescueCase {

        private int ageMonths;
        private double feedFee;
        private boolean foster;

        Nestling(String caseCode, String animalName, String species, String site, String ranger,
                 int dayCount, double dayRate, String state,
                 int ageMonths, double feedFee, boolean foster) {
            super(caseCode, animalName, species, site, ranger, dayCount, dayRate, state);
            this.ageMonths = ageMonths;
            this.feedFee = feedFee;
            this.foster = foster;
        }

        int ageMonths()      { return ageMonths; }
        double feedFee()     { return feedFee; }
        boolean foster()     { return foster; }

        @Override double grandTotal() {
            return fixedPortion() + feedFee + (foster ? 2500.0 : 0.0);
        }

        @Override String tier() {
            if (ageMonths <= 2 && foster) return "Critical";
            if (ageMonths <= 2 || foster) return "High";
            if (ageMonths <= 9)           return "Medium";
            return "Low";
        }

        @Override String family() { return "Orphaned Animal Rescue"; }

        @Override String finerPoints() {
            return "Age (months)          : " + ageMonths + "\n" +
                   "Feeding Fee           : " + rands(feedFee) + "\n" +
                   "Foster Care           : " + (foster ? "Yes" : "No");
        }

        @Override public void commence() { state(ENGAGED); }
        @Override public void finalise() { state(RESOLVED); }

        @Override public String card() {
            return "Case ID           : " + caseCode() + "\n" +
                   "Type              : " + family() + "\n" +
                   "Species           : " + species() + "\n" +
                   "Ranger            : " + ranger() + "\n" +
                   "Priority          : " + tier() + "\n" +
                   "Status            : " + state() + "\n" +
                   "Total Cost        : " + rands(grandTotal());
        }
    }

    // Endangered rescue: base + security + R8 000 if specialist team needed.
    // Tier: Critical if team AND critically endangered; High if either; Medium if endangered; else Low.
    static class Scarce extends RescueCase {

        private String redCategory;
        private double securityFee;
        private boolean specialistTeam;

        Scarce(String caseCode, String animalName, String species, String site, String ranger,
               int dayCount, double dayRate, String state,
               String redCategory, double securityFee, boolean specialistTeam) {
            super(caseCode, animalName, species, site, ranger, dayCount, dayRate, state);
            this.redCategory = redCategory;
            this.securityFee = securityFee;
            this.specialistTeam = specialistTeam;
        }

        String redCategory()       { return redCategory; }
        double securityFee()       { return securityFee; }
        boolean specialistTeam()   { return specialistTeam; }

        @Override double grandTotal() {
            return fixedPortion() + securityFee + (specialistTeam ? 8000.0 : 0.0);
        }

        @Override String tier() {
            boolean hot = "Critically Endangered".equalsIgnoreCase(redCategory);
            if (specialistTeam && hot) return "Critical";
            if (specialistTeam || hot) return "High";
            if ("Endangered".equalsIgnoreCase(redCategory)) return "Medium";
            return "Low";
        }

        @Override String family() { return "Endangered Species Rescue"; }

        @Override String finerPoints() {
            return "Red Category          : " + redCategory + "\n" +
                   "Security Fee          : " + rands(securityFee) + "\n" +
                   "Specialist Team       : " + (specialistTeam ? "Yes" : "No");
        }

        @Override public void commence() { state(ENGAGED); }
        @Override public void finalise() { state(RESOLVED); }

        @Override public String card() {
            return "Case ID           : " + caseCode() + "\n" +
                   "Type              : " + family() + "\n" +
                   "Species           : " + species() + "\n" +
                   "Ranger            : " + ranger() + "\n" +
                   "Priority          : " + tier() + "\n" +
                   "Status            : " + state() + "\n" +
                   "Total Cost        : " + rands(grandTotal());
        }
    }

    // Business layer: ArrayList of cases, unique-ID enforcement, aggregate totals.
    static class Ledger {

        private final ArrayList<RescueCase> entries = new ArrayList<>();

        void file(RescueCase rc) {
            if (rc == null) throw new IllegalArgumentException("Case cannot be null.");
            String id = rc.caseCode();
            if (id == null || id.trim().isEmpty())
                throw new IllegalArgumentException("Case ID cannot be blank.");
            if (find(id) != null)
                throw new IllegalArgumentException("Case ID already exists: " + id);
            entries.add(rc);
        }

        RescueCase find(String id) {
            if (id == null) return null;
            for (RescueCase rc : entries)
                if (rc.caseCode().equalsIgnoreCase(id.trim())) return rc;
            return null;
        }

        boolean setState(String id, String state) {
            RescueCase rc = find(id);
            if (rc == null) return false;
            rc.state(state);
            return true;
        }

        ArrayList<RescueCase> entries() { return entries; }
        int size() { return entries.size(); }

        double sumTotal() {
            double sum = 0;
            for (RescueCase rc : entries) sum += rc.grandTotal();
            return sum;
        }

        boolean exists(String id) { return find(id) != null; }
    }

    // JOptionPane user interface. Delegates every business action to Ledger.
    static class Shell {

        private static final Ledger ledger = new Ledger();

        static void start() {
            boolean alive = true;
            while (alive) {
                String banner =
                        "=====================================\n" +
                        "WILDLIFE RESCUE OPERATIONS SYSTEM\n" +
                        "=====================================\n" +
                        "1. Create Rescue Case\n" +
                        "2. Search Rescue Case\n" +
                        "3. Update Rescue Status\n" +
                        "4. Display All Rescue Cases\n" +
                        "5. Rescue Report\n" +
                        "6. Exit\n" +
                        "=====================================\n" +
                        "Select an option:";

                String pick = JOptionPane.showInputDialog(null, banner, "WildLife SA", JOptionPane.PLAIN_MESSAGE);
                if (pick == null) { alive = false; continue; }

                switch (pick.trim()) {
                    case "1": newCase();     break;
                    case "2": findCase();    break;
                    case "3": shiftState();  break;
                    case "4": showAll();     break;
                    case "5": runReport();   break;
                    case "6": alive = false; say("Goodbye."); break;
                    default:  say("Invalid. Choose 1 to 6.");
                }
            }
        }

        private static void newCase() {
            String[] families = {
                "Injured Animal Rescue",
                "Orphaned Animal Rescue",
                "Endangered Species Rescue"
            };
            String choice = (String) JOptionPane.showInputDialog(
                    null, "Select rescue type:", "WildLife SA",
                    JOptionPane.QUESTION_MESSAGE, null, families, families[0]);
            if (choice == null) return;

            String code = need("Enter Rescue Case ID:");
            if (code == null) return;
            if (ledger.exists(code)) { say("ID already used."); return; }

            String animal = need("Enter Animal Name:");      if (animal == null) return;
            String species = need("Enter Species:");         if (species == null) return;
            String site = need("Enter Rescue Location:");    if (site == null) return;
            String ranger = need("Enter Assigned Ranger:");  if (ranger == null) return;
            Integer days = needInt("Enter Number of Rescue Days:"); if (days == null) return;
            Double rate = needDbl("Enter Daily Care Cost (R):");    if (rate == null) return;

            try {
                RescueCase rc;
                if (choice.equals(families[0])) {
                    String note = need("Enter Injury Description:");            if (note == null) return;
                    Double clinic = needZero("Veterinary Treatment Cost (R):"); if (clinic == null) return;
                    boolean op = yes("Is Surgery Required?");
                    rc = new Wounded(code, animal, species, site, ranger, days, rate, RescueProtocol.CREATED, note, clinic, op);
                } else if (choice.equals(families[1])) {
                    Integer age = needInt("Enter Estimated Age (Months):"); if (age == null) return;
                    Double feed = needZero("Feeding Cost (R):");            if (feed == null) return;
                    boolean foster = yes("Is Foster Care Required?");
                    rc = new Nestling(code, animal, species, site, ranger, days, rate, RescueProtocol.CREATED, age, feed, foster);
                } else {
                    String cat = need("Enter Conservation Classification:"); if (cat == null) return;
                    Double security = needZero("Security Cost (R):");        if (security == null) return;
                    boolean team = yes("Is a Specialist Team Required?");
                    rc = new Scarce(code, animal, species, site, ranger, days, rate, RescueProtocol.CREATED, cat, security, team);
                }
                ledger.file(rc);
                say("Case created.\n\n" + rc.card());
            } catch (IllegalArgumentException ex) {
                say(ex.getMessage());
            }
        }

        private static void findCase() {
            String code = need("Enter Rescue Case ID to search:");
            if (code == null) return;
            RescueCase rc = ledger.find(code);
            if (rc == null) { say("No case found: " + code); return; }
            panel("Rescue Case Details", detailed(rc));
        }

        private static void shiftState() {
            String code = need("Enter Rescue Case ID to update:");
            if (code == null) return;
            RescueCase rc = ledger.find(code);
            if (rc == null) { say("No case found: " + code); return; }

            String[] states = { RescueProtocol.ENGAGED, RescueProtocol.WATCHING, RescueProtocol.RESOLVED, RescueProtocol.CREATED };
            String next = (String) JOptionPane.showInputDialog(
                    null, "Choose new status for " + rc.caseCode() + ":",
                    "Update Status", JOptionPane.QUESTION_MESSAGE,
                    null, states, rc.state());
            if (next == null) return;

            ledger.setState(code, next);
            say("Status updated.\n\n" + rc.card());
        }

        private static void showAll() {
            ArrayList<RescueCase> list = ledger.entries();
            if (list.isEmpty()) { say("No rescue cases yet."); return; }

            StringBuilder sb = new StringBuilder();
            sb.append("ALL RESCUE CASES (").append(list.size()).append(")\n");
            sb.append("=====================================\n");
            for (RescueCase rc : list) {
                sb.append(detailed(rc)).append("\n-------------------------------------\n");
            }
            panel("All Rescue Cases", sb.toString());
        }

        private static void runReport() {
            ArrayList<RescueCase> list = ledger.entries();
            StringBuilder sb = new StringBuilder();
            sb.append("=====================================\n");
            sb.append("WILDLIFE RESCUE REPORT\n");
            sb.append("=====================================\n");

            if (list.isEmpty()) {
                sb.append("No rescue cases to report.\n");
            } else {
                for (RescueCase rc : list) {
                    sb.append("Case ID          : ").append(rc.caseCode()).append("\n");
                    sb.append("Type             : ").append(rc.family()).append("\n");
                    sb.append("Species          : ").append(rc.species()).append("\n");
                    sb.append("Location         : ").append(rc.site()).append("\n");
                    sb.append("Ranger           : ").append(rc.ranger()).append("\n");
                    sb.append("Priority         : ").append(rc.tier()).append("\n");
                    sb.append("Status           : ").append(rc.state()).append("\n");
                    sb.append("Total Cost       : ").append(RescueCase.rands(rc.grandTotal())).append("\n");
                    sb.append("-------------------------------------\n");
                }
            }
            sb.append("=====================================\n");
            sb.append("Total Cases      : ").append(ledger.size()).append("\n");
            sb.append("Total Cost       : ").append(RescueCase.rands(ledger.sumTotal())).append("\n");
            sb.append("=====================================\n");
            panel("Wildlife Rescue Report", sb.toString());
        }

        private static String detailed(RescueCase rc) {
            return "Case ID           : " + rc.caseCode() + "\n" +
                   "Animal Name       : " + rc.animalName() + "\n" +
                   "Type              : " + rc.family() + "\n" +
                   "Species           : " + rc.species() + "\n" +
                   "Location          : " + rc.site() + "\n" +
                   "Ranger            : " + rc.ranger() + "\n" +
                   "Days              : " + rc.dayCount() + "\n" +
                   "Daily Cost        : " + RescueCase.rands(rc.dayRate()) + "\n" +
                   "Status            : " + rc.state() + "\n" +
                   "Priority          : " + rc.tier() + "\n" +
                   rc.finerPoints() + "\n" +
                   "Total Cost        : " + RescueCase.rands(rc.grandTotal()) + "\n";
        }

        private static void panel(String title, String body) {
            JTextArea area = new JTextArea(body);
            area.setEditable(false);
            area.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
            JScrollPane scroll = new JScrollPane(area);
            scroll.setPreferredSize(new Dimension(560, 440));
            JOptionPane.showMessageDialog(null, scroll, title, JOptionPane.INFORMATION_MESSAGE);
        }

        // --- validated input helpers ---

        private static String need(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                if (!s.trim().isEmpty()) return s.trim();
                say("Cannot be blank.");
            }
        }

        private static Integer needInt(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    int v = Integer.parseInt(s.trim());
                    if (v > 0) return v;
                    say("Must be greater than zero.");
                } catch (NumberFormatException e) {
                    say("Enter a whole number.");
                }
            }
        }

        private static Double needDbl(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v > 0) return v;
                    say("Must be greater than zero.");
                } catch (NumberFormatException e) {
                    say("Enter a number.");
                }
            }
        }

        private static Double needZero(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v >= 0) return v;
                    say("Cannot be negative.");
                } catch (NumberFormatException e) {
                    say("Enter a number.");
                }
            }
        }

        private static boolean yes(String prompt) {
            return JOptionPane.showConfirmDialog(null, prompt, "WildLife SA",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
        }

        private static void say(String msg) {
            JOptionPane.showMessageDialog(null, msg, "WildLife SA", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}