package com.mycompany.khulile_mambane_prog6112_assignment_2;

import com.mycompany.khulile_mambane_prog6112_assignment_2.Khulile_Mambane_Prog6112_Assignment_2.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LedgerTest {

    private Ledger ledger;

    @BeforeEach
    public void setUp() {
        ledger = new Ledger();
    }

    // ---- cost calculations ----

    @Test public void woundedNoOperation() {
        Wounded w = new Wounded("R01", "Tusker", "African Elephant", "Kruger", "A",
                5, 2000, RescueProtocol.CREATED, "Snare", 8500, false);
        assertEquals(18500, w.grandTotal(), 0.001);
    }

    @Test public void woundedWithOperation() {
        Wounded w = new Wounded("R02", "Tusker", "African Elephant", "Kruger", "A",
                5, 2000, RescueProtocol.CREATED, "Snare", 8500, true);
        assertEquals(23500, w.grandTotal(), 0.001);
    }

    @Test public void nestlingNoFoster() {
        Nestling n = new Nestling("R03", "Nandi", "White Rhino", "Hluhluwe", "B",
                10, 600, RescueProtocol.CREATED, 4, 3000, false);
        assertEquals(9000, n.grandTotal(), 0.001);
    }

    @Test public void nestlingWithFoster() {
        Nestling n = new Nestling("R04", "Nandi", "White Rhino", "Hluhluwe", "B",
                10, 600, RescueProtocol.CREATED, 4, 3000, true);
        assertEquals(11500, n.grandTotal(), 0.001);
    }

    @Test public void scarceNoTeam() {
        Scarce s = new Scarce("R05", "Shadow", "Black Rhino", "Addo", "C",
                7, 800, RescueProtocol.CREATED, "Critically Endangered", 12000, false);
        assertEquals(17600, s.grandTotal(), 0.001);
    }

    @Test public void scarceWithTeam() {
        Scarce s = new Scarce("R06", "Shadow", "Black Rhino", "Addo", "C",
                7, 800, RescueProtocol.CREATED, "Critically Endangered", 12000, true);
        assertEquals(25600, s.grandTotal(), 0.001);
    }

    // ---- priority tiers ----

    @Test public void woundedCritical() {
        Wounded w = new Wounded("R07", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, RescueProtocol.CREATED, "Gunshot", 15000, true);
        assertEquals("Critical", w.tier());
    }

    @Test public void woundedHigh() {
        Wounded w = new Wounded("R08", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, RescueProtocol.CREATED, "Fracture", 13000, false);
        assertEquals("High", w.tier());
    }

    @Test public void woundedMedium() {
        Wounded w = new Wounded("R09", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, RescueProtocol.CREATED, "Wound", 5000, false);
        assertEquals("Medium", w.tier());
    }

    @Test public void woundedLow() {
        Wounded w = new Wounded("R10", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, RescueProtocol.CREATED, "Cut", 1000, false);
        assertEquals("Low", w.tier());
    }

    @Test public void nestlingCritical() {
        Nestling n = new Nestling("R11", "Baby Elephant", "African Elephant", "Addo", "E",
                5, 400, RescueProtocol.CREATED, 2, 3000, true);
        assertEquals("Critical", n.tier());
    }

    @Test public void nestlingHigh() {
        Nestling n = new Nestling("R12", "Baby Elephant", "African Elephant", "Addo", "E",
                5, 400, RescueProtocol.CREATED, 2, 3000, false);
        assertEquals("High", n.tier());
    }

    @Test public void nestlingMedium() {
        Nestling n = new Nestling("R13", "Young Elephant", "African Elephant", "Addo", "E",
                5, 400, RescueProtocol.CREATED, 8, 3000, false);
        assertEquals("Medium", n.tier());
    }

    @Test public void nestlingLow() {
        Nestling n = new Nestling("R14", "Juvenile", "African Elephant", "Addo", "E",
                5, 400, RescueProtocol.CREATED, 18, 3000, false);
        assertEquals("Low", n.tier());
    }

    @Test public void scarceCritical() {
        Scarce s = new Scarce("R15", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, RescueProtocol.CREATED, "Critically Endangered", 9000, true);
        assertEquals("Critical", s.tier());
    }

    @Test public void scarceHigh() {
        Scarce s = new Scarce("R16", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, RescueProtocol.CREATED, "Critically Endangered", 9000, false);
        assertEquals("High", s.tier());
    }

    @Test public void scarceMedium() {
        Scarce s = new Scarce("R17", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, RescueProtocol.CREATED, "Endangered", 9000, false);
        assertEquals("Medium", s.tier());
    }

    @Test public void scarceLow() {
        Scarce s = new Scarce("R18", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, RescueProtocol.CREATED, "Vulnerable", 9000, false);
        assertEquals("Low", s.tier());
    }

    // ---- status updates ----

    @Test public void commenceMarksEngaged() {
        Wounded w = new Wounded("R19", "Zebra", "Plains Zebra", "Etosha", "G",
                4, 150, RescueProtocol.CREATED, "Sprain", 1200, false);
        w.commence();
        assertEquals(RescueProtocol.ENGAGED, w.state());
    }

    @Test public void finaliseMarksResolved() {
        Nestling n = new Nestling("R20", "Baby Giraffe", "Giraffe", "Etosha", "G",
                4, 150, RescueProtocol.CREATED, 4, 800, false);
        n.finalise();
        assertEquals(RescueProtocol.RESOLVED, n.state());
    }

    // ---- search ----

    @Test public void findExisting() {
        Wounded w = new Wounded("R21", "Leopard", "African Leopard", "Sabie", "H",
                2, 250, RescueProtocol.CREATED, "Snare", 3000, false);
        ledger.file(w);
        assertNotNull(ledger.find("R21"));
        assertEquals("Leopard", ledger.find("R21").animalName());
    }

    @Test public void findMissing() {
        assertNull(ledger.find("R999"));
    }

    @Test public void findCaseInsensitive() {
        Nestling n = new Nestling("r22", "Baby Lion", "African Lion", "Kgalagadi", "I",
                3, 200, RescueProtocol.CREATED, 2, 900, true);
        ledger.file(n);
        assertNotNull(ledger.find("R22"));
    }

    // ---- duplicates and validation ----

    @Test public void rejectDuplicate() {
        ledger.file(new Wounded("R23", "Buffalo", "African Buffalo", "Hluhluwe", "J",
                5, 180, RescueProtocol.CREATED, "Horn", 2500, false));
        Wounded clash = new Wounded("R23", "Buffalo", "African Buffalo", "Hluhluwe", "J",
                5, 180, RescueProtocol.CREATED, "Horn", 2500, false);
        assertThrows(IllegalArgumentException.class, () -> ledger.file(clash));
    }

    @Test public void rejectDuplicateCaseInsensitive() {
        ledger.file(new Scarce("R24", "Pangolin", "Ground Pangolin", "Limpopo", "K",
                4, 350, RescueProtocol.CREATED, "Endangered", 3000, false));
        Scarce clash = new Scarce("r24", "Pangolin", "Ground Pangolin", "Limpopo", "K",
                4, 350, RescueProtocol.CREATED, "Endangered", 3000, false);
        assertThrows(IllegalArgumentException.class, () -> ledger.file(clash));
    }

    @Test public void rejectBlankId() {
        Wounded w = new Wounded("   ", "Bird", "Eagle", "Drakensberg", "L",
                2, 100, RescueProtocol.CREATED, "Wing", 500, false);
        assertThrows(IllegalArgumentException.class, () -> ledger.file(w));
    }

    @Test public void rejectNull() {
        assertThrows(IllegalArgumentException.class, () -> ledger.file(null));
    }

    // ---- totals ----

    @Test public void totalsAcrossTwoCases() {
        ledger.file(new Wounded("R25", "Elephant", "African Elephant", "Kruger", "A",
                5, 100, RescueProtocol.CREATED, "Leg", 2000, false)); // 2500
        ledger.file(new Nestling("R26", "Baby Rhino", "White Rhino", "Hluhluwe", "B",
                10, 200, RescueProtocol.CREATED, 6, 1500, true)); // 6000

        assertEquals(2, ledger.size());
        assertEquals(8500, ledger.sumTotal(), 0.001);
    }
}